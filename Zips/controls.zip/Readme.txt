Program Name: Controls Plus
Platform:     TI-83 Plus
Author:	      Peter Jedraszczak
	      pbjiam@hotmail.com
	      http://petershomepage.tripod.com
Date:	      August 11, 2000
This is my first attempt at an ASM program. So if there are any bugs report them to me and I will try to fix them.


Size: about 959 bytes

Description:
	This program lets you toggle some system flags such as text inverse or lower case. New things have been added to this updated version. Things such as battery check and cursor/on/off have been put in to make things better.

Future Versions:
	--Code Optimizations to make program run faster and be smaller
	--More system flags (you may send me suggestions of what to put in)
	--Releasing the Source code when I can fix it all up
	--Add bar at bottom of the screen that shows free memory
	--Possibly add Password protection

History
	--Initial Public Release Version 1.0
	July 29 2000
	--Public Release Version 1.1
	August 3 2000
	--Public release Version 1.1
	August 11 2000
	Now for Mirage OS