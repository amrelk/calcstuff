Prgm2Hex 1.0 (Nov. 28th, 2002)
By: Houston McConnell

Thank you for downloading Prgm2Hex for the TI-83 Plus.

Description:
This program is a very useful on-calc (8xp) to (hex) converter, especially if you make assembly programs.

This program has two main purposes:

-to get the hex code of a basic prgm (for Prgms that create Prgms)
 This program is can be used to get the hex code for the tokens in a basic prgm. You can use this as data in the source code of a program that creates a basic program.

-to decompile Asm Prgms for any other cause
 This program does about the exact opposite of 'AsmComp(' for an assembly program.

Keys:
[Left] / [Right] - Used to select the prgm to decompile
[Enter] - Start Converting to Hex code

Use:
Run the program from Mirage. Select desired PrgmName

Output:
After you Run the Prgm and Select the Prgm to use, It will display a message and return to Mirage. To view the hex-code of the selected prgm, goto the [PRGM]-Edit menu and then Choose:  prgmZPRGMDAT

Bugs:
I haven't found any...
yet!