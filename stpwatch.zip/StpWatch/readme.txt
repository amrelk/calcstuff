Stop Watch by Brian Coventry aka thepenguin77

This stop watch is perfectly accurate and goes all the way to the hundreds place.

It uses the internal crystal to update a number 128 times per second, meaning high precision.

Also includes 4 splits.

2nd - start
Mode - split
Del - clear splits
Clear - quit
0 - reset during pause


This program is very useful for physics. And it can even be used as a game when you try to get .01 (which is possible)

Sorry to those who have 83+'s. I used fast mode and the crystal timers which your calculator does not have.
However, if the warning screen pops up in WabbitEmu (as it does for me) just press Graph to pass it. (This will crash a real 83)

If you are going to modify the game, I just ask that you do for the betterment of the game and don't 
steal the credit. (i.e. change "By Brian Coventry" to something else)


;#########################
	Contact
;#########################

If you need to contact me you can:

email me at bcoventry@live.com (although I hardly check it and facebook is overloading it)
	or
pm me at unitedti.org  thepenguin77